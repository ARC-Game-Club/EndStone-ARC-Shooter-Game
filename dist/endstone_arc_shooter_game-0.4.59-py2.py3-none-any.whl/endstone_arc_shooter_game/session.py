# -*- coding: utf-8 -*-
"""大厅 / 对局状态机。不依赖 Endstone，便于单测。"""
from __future__ import annotations

import math
import random
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from endstone_arc_shooter_game.config import IMPLEMENTED_MODES, build_runtime_map_cfg, mode_playable

STATE_LOBBY = "lobby"
STATE_COUNTDOWN = "countdown"
STATE_BUYING = "buying"
STATE_PLAYING = "playing"

TEAM_A = "a"
TEAM_B = "b"


def pick_spawn(spawns: List[Dict[str, Any]]) -> Dict[str, float]:
    spawn = random.choice(spawns)
    radius = float(spawn.get("radius") or 0)
    x = float(spawn["x"])
    y = float(spawn["y"])
    z = float(spawn["z"])
    if radius > 0:
        angle = random.uniform(0, 2 * math.pi)
        dist = random.uniform(0, radius)
        x += dist * math.cos(angle)
        z += dist * math.sin(angle)
    return {
        "x": x,
        "y": y,
        "z": z,
        "yaw": spawn.get("yaw"),
        "pitch": spawn.get("pitch"),
    }


def apply_kill(
    score_a: int,
    score_b: int,
    killer_team: str,
    victim_team: str,
    target_score: int,
    kill_reward: int,
    killer_points: int,
) -> Dict[str, Any]:
    friendly = killer_team == victim_team
    if friendly:
        if killer_team == TEAM_A:
            score_a = max(0, score_a - 1)
        else:
            score_b = max(0, score_b - 1)
        reward = 0
    else:
        if killer_team == TEAM_A:
            score_a += 1
        else:
            score_b += 1
        reward = max(0, int(kill_reward))
        killer_points += reward
    winner = None
    if not friendly:
        if score_a >= target_score:
            winner = TEAM_A
        elif score_b >= target_score:
            winner = TEAM_B
    return {
        "score_a": score_a,
        "score_b": score_b,
        "killer_points": killer_points,
        "reward": reward,
        "friendly": friendly,
        "winner": winner,
    }


def apply_ffa_kill(
    kills: int,
    target_score: int,
    kill_reward: int,
    killer_points: int,
) -> Dict[str, Any]:
    """个人死斗击杀结算：没有队友，不存在友伤；个人击杀数达 target 即达标。

    winner（谁获胜）由调用方用玩家名拼——这里只做计数与达标判断。
    """
    reward = max(0, int(kill_reward))
    kills += 1
    points = killer_points + reward
    return {
        "kills": kills,
        "killer_points": points,
        "reward": reward,
        "hit_target": kills >= target_score,
    }


def first_empty_or_first(occupied: List[Optional[str]], capacity: int) -> int:
    if capacity <= 0:
        return 0
    for i in range(capacity):
        if i >= len(occupied) or not occupied[i]:
            return i
    return 0


def compute_bot_online_quota(
    waiting_lobbies: int,
    playable_maps: int,
    *,
    base: int,
    per_lobby: int,
    hard_max: int,
) -> int:
    """假人在线配额：以地图规模（可玩地图数）和等待中大厅数决定。

    公式：clamp(base + per_lobby×等待房数, base, min(hard_max, max(base, 地图数×2)))。
    大厅数本就 ≤ 可玩地图数，地图数×2 是"每张图一间房、每间至少两人"的
    天花板；下限 base 保证 AI 自建房一直有人能开局。
    """
    base = max(0, int(base))
    per_lobby = max(0, int(per_lobby))
    hard_max = max(1, int(hard_max))
    ceiling = min(hard_max, max(base, max(0, int(playable_maps)) * 2))
    return max(base, min(base + per_lobby * max(0, int(waiting_lobbies)), ceiling))


def pick_assist_lobby(lobbies_desc: List[Dict[str, Any]]) -> Optional[str]:
    """60s 巡检选目标：真人建的、还在等待/倒计时、没满、人还没齐的大厅里
    挑 lobby_started_at 最早（等得最久）的那间；None = 无需迁移。

    lobbies_desc 每项：{lobby_id, started_at, has_human, waiting, joinable,
    ready}——由插件侧统计填充（has_human=场上有真人；waiting=LOBBY/
    COUNTDOWN；joinable=can_join()；ready=teams_ready_to_start()）。
    """
    best_id: Optional[str] = None
    best_key: Optional[Tuple[float, str]] = None
    for d in lobbies_desc:
        if not (
            d.get("has_human")
            and d.get("waiting")
            and d.get("joinable")
            and not d.get("ready")
        ):
            continue
        try:
            started = float(d.get("started_at") or 0.0)
        except (TypeError, ValueError):
            started = 0.0
        lobby_id = str(d.get("lobby_id") or "")
        if not lobby_id:
            continue
        key = (started, lobby_id)
        if best_key is None or key < best_key:
            best_key = key
            best_id = lobby_id
    return best_id


@dataclass
class PlayerState:
    name: str
    team: str
    points: int
    kills: int = 0
    deaths: int = 0
    assists: int = 0
    team_kills: int = 0
    primary_id: Optional[str] = None
    secondary_id: Optional[str] = None
    melee_id: Optional[str] = None
    armor_id: Optional[str] = None
    gadgets: List[Optional[str]] = field(default_factory=list)
    still_in: bool = True

@dataclass
class Lobby:
    admin: str
    lobby_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    map_id: Optional[str] = None
    mode: Optional[str] = None
    map_cfg: Optional[Dict[str, Any]] = None
    # 默认随机；开局时再占用空余地图。手动选图后置 False。
    prefer_random_map: bool = True
    prefer_random_mode: bool = True
    state: str = STATE_LOBBY
    lobby_started_at: float = 0.0
    countdown_ends_at: float = 0.0
    buy_ends_at: float = 0.0
    match_ends_at: float = 0.0
    players: Dict[str, PlayerState] = field(default_factory=dict)
    score_a: int = 0
    score_b: int = 0
    history: List[PlayerState] = field(default_factory=list)
    # 已提示过的秒数标记，避免 tick 重复广播（如 "60"、"10"…"1"）
    announced_secs: Set[str] = field(default_factory=set)

    @property
    def display_name(self) -> str:
        if self.map_cfg:
            return str(self.map_cfg.get("display_name") or self.map_cfg.get("id") or self.lobby_id)
        return self.lobby_id

    @property
    def active_mode(self) -> str:
        if self.map_cfg:
            return str(self.map_cfg.get("mode") or self.mode or "tdm").lower()
        return str(self.mode or "").lower()

    @property
    def max_per_team(self) -> int:
        if self.map_cfg:
            return int(self.map_cfg.get("max_players_per_team") or 8)
        return 8

    @property
    def target_score(self) -> int:
        if self.map_cfg:
            return int(self.map_cfg.get("target_score") or 50)
        return 50

    @property
    def match_time_minutes(self) -> int:
        if self.map_cfg:
            try:
                return max(1, int(self.map_cfg.get("match_time_minutes") or 5))
            except (TypeError, ValueError):
                return 5
        return 5

    @property
    def match_time_seconds(self) -> int:
        return self.match_time_minutes * 60

    def team_name(self, team_id: str) -> str:
        team = (self.map_cfg.get("teams") or {}).get(team_id) if self.map_cfg else {}
        team = team or {}
        return str(team.get("name") or ("红队" if team_id == TEAM_A else "蓝队"))

    def team_spawns(self, team_id: str) -> List[Dict[str, Any]]:
        if not self.map_cfg:
            return []
        team = (self.map_cfg.get("teams") or {}).get(team_id) or {}
        return list(team.get("spawns") or [])

    def online_players(self) -> List[PlayerState]:
        return [p for p in self.players.values() if p.still_in]

    def team_count(self, team_id: str) -> int:
        return sum(1 for p in self.online_players() if p.team == team_id)

    def player_count(self) -> int:
        return len(self.online_players())

    def pick_join_team(self) -> Optional[str]:
        if self.active_mode == "ffa":
            # 个人死斗：全员进红池，max_players_per_team 此时是总人数上限
            return TEAM_A if self.team_count(TEAM_A) < self.max_per_team else None
        a = self.team_count(TEAM_A)
        b = self.team_count(TEAM_B)
        cap = self.max_per_team
        if a < cap and (a <= b or b >= cap):
            return TEAM_A
        if b < cap:
            return TEAM_B
        if a < cap:
            return TEAM_A
        return None

    def can_join(self) -> Tuple[bool, str]:
        if self.pick_join_team() is None:
            return False, "full"
        return True, "ok"

    def join(self, player_name: str, starting_points: int, now: Optional[float] = None) -> Tuple[bool, str]:
        now = time.time() if now is None else now
        ok, reason = self.can_join()
        if not ok:
            return False, reason
        team = self.pick_join_team()
        if team is None:
            return False, "full"
        became_admin = self.player_count() == 0
        if self.lobby_started_at <= 0:
            self.lobby_started_at = now
        if not self.admin:
            self.admin = player_name
            became_admin = True
        self.players[player_name] = PlayerState(
            name=player_name,
            team=team,
            points=int(starting_points),
        )
        return True, "admin" if became_admin else "ok"

    def leave(self, player_name: str) -> Optional[str]:
        ps = self.players.pop(player_name, None)
        if ps is None:
            return None
        ps.still_in = False
        if self.state in (STATE_BUYING, STATE_PLAYING):
            self.history.append(ps)
        new_admin = None
        if self.admin == player_name:
            remaining = self.online_players()
            self.admin = remaining[0].name if remaining else None
            new_admin = self.admin
        return new_admin

    def kick(self, target_name: str) -> bool:
        if target_name not in self.players:
            return False
        if target_name == self.admin:
            return False
        self.players.pop(target_name, None)
        return True

    def set_team(self, player_name: str, team: str) -> Tuple[bool, str]:
        ps = self.players.get(player_name)
        if ps is None:
            return False, "missing"
        if team not in (TEAM_A, TEAM_B):
            return False, "bad_team"
        if ps.team == team:
            return True, "same"
        if self.team_count(team) >= self.max_per_team:
            return False, "full"
        ps.team = team
        return True, "ok"

    def set_map_and_mode(self, map_cfg: Dict[str, Any], mode: str) -> Tuple[bool, str]:
        mode_key = str(mode or "").strip().lower()
        if mode_key not in IMPLEMENTED_MODES:
            return False, "unimplemented"
        if not mode_playable(map_cfg, mode_key):
            return False, "not_ready"
        runtime = build_runtime_map_cfg(map_cfg, mode_key)
        if runtime is None:
            return False, "not_ready"
        self.map_id = map_cfg["id"]
        self.mode = mode_key
        self.map_cfg = runtime
        return True, "ok"

    def clear_map_selection(self) -> None:
        self.map_id = None
        self.mode = None
        self.map_cfg = None

    def set_prefer_random(self, *, map_: bool = True, mode: bool = True) -> None:
        self.prefer_random_map = bool(map_)
        self.prefer_random_mode = bool(mode)
        if self.prefer_random_map:
            self.clear_map_selection()

    def can_start(self) -> Tuple[bool, str]:
        if self.state != STATE_LOBBY:
            return False, "not_lobby"
        has_map = bool(self.map_id and self.mode and self.map_cfg)
        if not has_map and not self.prefer_random_map:
            return False, "need_map"
        if self.player_count() < 2:
            return False, "need_players"
        if self.active_mode == "ffa":
            # 个人死斗：没有第二队，只看人数与红池出生点
            if has_map and not self.team_spawns(TEAM_A):
                return False, "need_spawns"
            return True, "ok"
        if self.team_count(TEAM_A) == 0 or self.team_count(TEAM_B) == 0:
            return False, "need_players"
        if has_map:
            if self.active_mode not in IMPLEMENTED_MODES:
                return False, "unimplemented"
            if not self.team_spawns(TEAM_A) or not self.team_spawns(TEAM_B):
                return False, "need_spawns"
        return True, "ok"

    def begin_countdown(self, countdown_seconds: int, now: Optional[float] = None) -> None:
        now = time.time() if now is None else now
        self.state = STATE_COUNTDOWN
        self.countdown_ends_at = now + max(1, int(countdown_seconds))
        self.announced_secs = set()

    def begin_buy(self, buy_seconds: int, now: Optional[float] = None) -> None:
        now = time.time() if now is None else now
        self.state = STATE_BUYING
        self.buy_ends_at = now + max(0, int(buy_seconds))
        self.score_a = 0
        self.score_b = 0
        self.announced_secs = set()

    def begin_playing(self, match_seconds: int = 300, now: Optional[float] = None) -> None:
        now = time.time() if now is None else now
        self.state = STATE_PLAYING
        self.match_ends_at = now + max(1, int(match_seconds))
        self.announced_secs = set()

    def cancel_countdown(self) -> None:
        self.state = STATE_LOBBY
        self.countdown_ends_at = 0.0
        self.announced_secs = set()
        # 随机偏好时释放地图，避免空占
        if self.prefer_random_map:
            self.clear_map_selection()

    def lobby_timed_out(self, timeout_seconds: int, now: Optional[float] = None) -> bool:
        now = time.time() if now is None else now
        if self.state != STATE_LOBBY:
            return False
        return now - self.lobby_started_at >= timeout_seconds

    def countdown_remaining(self, now: Optional[float] = None) -> float:
        now = time.time() if now is None else now
        return max(0.0, self.countdown_ends_at - now)

    def buy_remaining(self, now: Optional[float] = None) -> float:
        now = time.time() if now is None else now
        return max(0.0, self.buy_ends_at - now)

    def match_remaining(self, now: Optional[float] = None) -> float:
        now = time.time() if now is None else now
        return max(0.0, self.match_ends_at - now)

    def match_timed_out(self, now: Optional[float] = None) -> bool:
        now = time.time() if now is None else now
        if self.state != STATE_PLAYING:
            return False
        return self.match_ends_at > 0 and now >= self.match_ends_at

    def mark_announced(self, key: str) -> bool:
        """首次标记成功返回 True，已提示过则 False。"""
        if key in self.announced_secs:
            return False
        self.announced_secs.add(key)
        return True

    def teams_ready_to_start(self) -> bool:
        if self.active_mode == "ffa":
            return self.player_count() >= 2
        return (
            self.player_count() >= 2
            and self.team_count(TEAM_A) > 0
            and self.team_count(TEAM_B) > 0
        )

    def winner_by_score(self) -> Optional[str]:
        if self.active_mode == "ffa":
            # 个人死斗：击杀最多者获胜（winner 是玩家名）；并列 → 平局
            rows = self.result_rows()
            if not rows:
                return None
            top = max(int(ps.kills) for ps in rows)
            leaders = [ps for ps in rows if int(ps.kills) == top]
            if len(leaders) != 1:
                return None
            return leaders[0].name
        if self.score_a > self.score_b:
            return TEAM_A
        if self.score_b > self.score_a:
            return TEAM_B
        return None

    def apply_player_kill(self, killer_name: str, victim_name: str, kill_reward: int) -> Optional[Dict[str, Any]]:
        killer = self.players.get(killer_name)
        victim = self.players.get(victim_name)
        if killer is None or victim is None:
            return None
        if not killer.still_in or not victim.still_in:
            return None
        if self.state not in (STATE_BUYING, STATE_PLAYING):
            return None
        if self.active_mode == "ffa":
            # 个人死斗：谁都不算队友，击杀永远非友伤；score_a 只作总击杀展示
            ffa = apply_ffa_kill(
                killer.kills,
                self.target_score,
                kill_reward,
                killer.points,
            )
            killer.kills = ffa["kills"]
            killer.points = ffa["killer_points"]
            victim.deaths += 1
            self.score_a += 1
            return {
                "score_a": self.score_a,
                "score_b": self.score_b,
                "killer_points": killer.points,
                "reward": ffa["reward"],
                "friendly": False,
                "winner": killer.name if ffa["hit_target"] else None,
                "killer": killer,
                "victim": victim,
            }
        result = apply_kill(
            self.score_a,
            self.score_b,
            killer.team,
            victim.team,
            self.target_score,
            kill_reward,
            killer.points,
        )
        self.score_a = result["score_a"]
        self.score_b = result["score_b"]
        killer.points = result["killer_points"]
        if not result["friendly"]:
            victim.deaths += 1
            killer.kills += 1
        else:
            killer.team_kills += 1
        result["killer"] = killer
        result["victim"] = victim
        return result

    def apply_assist(self, player_name: str) -> None:
        ps = self.players.get(player_name)
        if ps is None or not ps.still_in:
            return
        ps.assists += 1

    def apply_team_kill_credit(self, player_name: str) -> None:
        """友军伤害助攻式 TK（击杀者本人已在 apply_player_kill 计入）。"""
        ps = self.players.get(player_name)
        if ps is None or not ps.still_in:
            return
        ps.team_kills += 1

    def remaining_winner(self) -> Optional[str]:
        if self.active_mode == "ffa":
            # 个人死斗：全场只剩 1 人 → 他获胜（winner 是玩家名）
            online = self.online_players()
            return online[0].name if len(online) == 1 else None
        a = self.team_count(TEAM_A)
        b = self.team_count(TEAM_B)
        if a == 0 and b == 0:
            return None
        if a == 0:
            return TEAM_B
        if b == 0:
            return TEAM_A
        return None

    def result_rows(self) -> List[PlayerState]:
        rows = list(self.history)
        seen = {p.name for p in rows}
        for ps in self.players.values():
            if ps.name not in seen:
                rows.append(ps)
        return rows

    def record_purchase(self, player_name: str, weapon: Dict[str, Any], gadget_capacity: int) -> Tuple[int, Optional[str]]:
        from endstone_arc_shooter_game.loadout import record_owned

        ps = self.players.get(player_name)
        if ps is None:
            return 0, None
        wtype = str(weapon.get("type") or "")
        capacity = 1 if wtype in ("primary", "secondary", "melee", "armor") else max(0, int(gadget_capacity))
        return record_owned(ps, weapon, capacity)


# 兼容旧测试/引用
MapInstance = Lobby
